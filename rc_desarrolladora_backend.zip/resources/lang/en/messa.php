<?php

return [
  'role_store' => 'Rol creado',
  'role_update' => 'Rol editado',
  'role_delete' => 'Rol eliminado',
];
